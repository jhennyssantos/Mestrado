 Queue Manager is a module that's allow the OpenFlow Controller to set dinamic bandwidth allocation.  
